
Find license plate, car emblem and more - vdataset find-license-plate-car-emblem-and-more
==============================

This dataset was exported via roboflow.com on July 3, 2026 at 8:57 AM GMT

Roboflow is an end-to-end computer vision platform that helps you
* collaborate with your team on computer vision projects
* collect & organize images
* understand and search unstructured image data
* annotate, and create datasets
* export, train, and deploy computer vision models
* use active learning to improve your dataset over time

For state of the art Computer Vision training notebooks you can use with this dataset,
visit https://github.com/roboflow/notebooks

To find over 100k other datasets and pre-trained models, visit https://universe.roboflow.com

The dataset includes 41 images.
License-plate-car-emblem-side-mirror-fuel-cap-object-detection-hsnt3b7jsa5fy0jwbpy4 are annotated in YOLOv8 format.

No pre-processing or augmentation was applied.
