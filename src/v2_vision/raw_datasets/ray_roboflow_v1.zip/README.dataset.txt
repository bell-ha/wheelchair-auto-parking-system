# Find license plate, car emblem and more > find-license-plate-car-emblem-and-more
https://universe.roboflow.com/jongha/find-license-plate-car-emblem-and-more

Provided by a Roboflow user
License: Public Domain

