# license plate > 2022-11-09 6:31pm
https://universe.roboflow.com/sol-sol-7axi3/license-plate-z9vcu

Provided by a Roboflow user
License: CC BY 4.0

